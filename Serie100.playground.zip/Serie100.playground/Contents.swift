
/* Ronda del uno al cien en que bajo ciertas condiciones se despliega un mensaje */
import UIKit

var numero = 1...100







for resultado in numero {
    
    /* Variables para imprimir todo en la misma línea
     de número */
  
    var expresion1 : String = "          "
    var expresion2 : String = ""
    var expresion3 : String = ""
    
    if resultado % 5 == 0 {
        expresion1 = " #BINGO!!!"
        }
    
    if resultado % 2 == 0 {
        expresion2 = " PAR   "
        }
            
    if resultado % 2 != 0 {
        expresion2 = " IMPAR "
        }
                
    if resultado >= 30 && resultado <= 40 {
        expresion3 = "   #Viva SWIFT !!!"
    }
    
    if resultado < 10 {
        print("0\(resultado)\(expresion1)\(expresion2)\(expresion3)")
        
    }else{
        print("\(resultado)\(expresion1)\(expresion2)\(expresion3)")
    }
    
    

                        }




    

